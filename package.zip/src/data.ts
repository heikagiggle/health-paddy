export const navigation = [
    {
      name: 'Products',
      href: 'Products', 
    },
    {
      name: 'Features',
      href: 'Features',
    },
    {
      name: 'features',
      href: 'features',
    },
    {
      name: 'Pricing',
      href: 'Pricing',
    },
    {
      name: 'Support',
      href: 'Support',
    },
  ];