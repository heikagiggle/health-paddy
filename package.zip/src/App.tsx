
import './App.css'
import Home from "./Components/home/Home";
import Header from './Components/navbar/Header';

function App() {
 

  return (
    <>
      <div>
        <Header/>
        <Home />
      </div>
     
    </>
  )
}

export default App
